import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import PageHeader from "./components/PageHeader/PageHeader";
import UsersProvider, { UserContext } from "./context/UsersProvider";
import SearchPage from "./Pages/SearchPage/SearchPage";
import WebFont from 'webfontloader';
import { useContext, useEffect } from "react";
import UserPage from "./Pages/UserPage/UserPage";
import PageLoadingNoTranslation from "./components/Loading/Loading";
import PagesWrapper from "./components/PagesWrapper/PagesWrapper";

/*

Lite kort inför projektet:

Har aldrig byggt någon avancerad sök tidigare i front-end. Normalt sett har vi hanterat sökfunktionaliteten i backend. Dvs att man gör fetchen på söksträngen och att backend tar hand om det magiska och returnerar resultat.

Här är det lite annorlunda då jag inte ser någonstans där man anropar api med exempelvis:

?search=joakim...

I detta api gör jag bara ett anrop och sätter därför all data en gång, iom att det ska bli två sidor (Kanske fler någon gång) lägger jag all data i ett kontext som jag kan nå från överallt innnuti appen.

Så jag har aldrig byggt på detta sätt tidigare, känns lte bakvänt på något vis. Men jag ska göra mitt bästa, osäker på hur magisk jag kan göra söken på en vecka.

*/

function App() {
  useEffect(() => {
    WebFont.load({
      google: {
        families: ['Poppins:400,700', 'Roboto: 400, 700']
      }
    });
  }, []);

  return (
    <div className="App">
      <UsersProvider>
        
        <>
          <PagesWrapper>
            <>
              <PageHeader/>
              <Router basename="/usersearch/build">
                <Routes>
                  <Route path="/" element={<SearchPage/>} />
                  <Route path="/:search" element={<UserPage/>} />
                </Routes>
              </Router>
            </>
          </PagesWrapper>
        </>
        
      </UsersProvider>
    </div>
    
  );
}

export default App;