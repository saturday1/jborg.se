import { useContext, useEffect, useRef, useState } from "react";
import Filters from "../../components/Filters/Filters";
import SortBy from "../../components/SortBy/SortBy";
import ToggleDropdown from "../../components/ToggleDropdown/ToggleDropdown";
import UserCard from "../../components/UserCard/UserCard";
import { UserContext } from "../../context/UsersProvider";
import { api } from "../../types";
import { observer } from "../../utils/intersectionObserver";
import styles from "./SearchPage.module.scss"

export default function SearchPage () {
  // Av okänd anledning renderar inte sidan om när jag sorterat och kör setUsers från SortBy callback.

  const [initUsers, loading] = useContext(UserContext)
  // Hämta in users från kontext

  // IntersectionObserver

  const observerRef = useRef<null | HTMLDivElement>(null);
  // Skapar en ref så att jag kan lyssna via useEffect när card-elementen finns.

  const [users, setUsers] = useState(initUsers && initUsers); // Sätter initUsers här så att jag kan ändra denna array utan att påverka initUsers som är konstant

  useEffect(() => {
    // Dessa är elementen vi ska animera
    const cards = document.querySelectorAll('.observer_card');

    // Bevaka korten
    cards.forEach(card => {
      // "observer" finns som utility funktion för smidig återanvändning
      observer.observe(card);
    })

  }, [observerRef, users]) // Lyssna på ifall users eller observeRef ändras

  const [searchVal, setSearchVal] = useState(""); // Sök text value
  const nations = initUsers?.reduce((nations, user) => {
    return !nations.some(nation => nation === user.nat) ? [
      ...nations,
      user.nat
    ] : nations
  }, [] as string[]);

  // Och alla kön
  const genders = initUsers?.reduce((genders, user) => {
    return !genders.some(gender => gender === user.gender) ? [
      ...genders,
      user.gender
    ] : genders
  }, [] as string[]);

  // Sätter upp "filtergrund" som kan skickas till Filters-komponenten för att rendera filtreringsknappar automagiskt. Skickar bara in key : value från user där value alltid är string[]. Annars kommer filterkomponenten krascha just nu. Dvs, exempelvis location kommer ej fungera i denna lösningen då value är ett objekt.

  // Only set type [key:string] : string[] to filter constant
  const filters = {
    nat: nations ? nations : [], 
    gender: genders ? genders : []
    //Försäkrar mig om att det alltid skickas en array som value, tom array ifall det skulle vara undefined, vilket det inte ska bli, men kan teoretiskt.
  }

  const [filterCount, setFilterCount] = useState(0);

  return <div className={styles.searchpage_wrapper}>
    <div className={styles.input_wrapper}>
      <h1>Sök användare</h1>
      <div className={styles.search}>
        <input type="text" placeholder="John Doe" role="search" value={searchVal} onChange={(e) => setSearchVal(e.target.value)} className={styles.input_search} autoFocus />
      </div>
    </div>
    <div className={styles.sorting_wrapper}>
      
      <div>
        <h2>Filtrera</h2>
        <ToggleDropdown title={`Filter${typeof(filterCount) === 'number' && filterCount > 0
          ? ` (${filterCount})`
          : ''
        }`} icon="fa-solid fa-sliders">
          <Filters 
            filters={filters} 
            searchVal={searchVal} 
            initUsers={initUsers} 
            setUsers={(users:api.User[]) => setUsers(users)}
            filterCount={(count:number) => setFilterCount(count)}
          />
        </ToggleDropdown>
      </div>
      <SortBy 
        users={users} 
        setUsers={(sortedUsers: api.User[]) => {
          setUsers(sortedUsers)
        }}
      />

    </div>
      
    {/* aria-live="assertive" gör att innehållet läses upp när det uppdateras dynamiskt */}
    <div className={styles.result_wrapper} aria-live="polite">
      <h2>Resultat {users && <>({users.length} st.)</>}</h2>
      <div className={styles.card_wrapper} ref={observerRef}>
        {// Loopa ut användare
        users && users.length > 0
          ? users.map((user,i) => {
          return <UserCard key={user.id.value + i} user={user}/>
          })
          : <>Inget resultat</>
        }
      </div>
    </div>
    
  </div>
}