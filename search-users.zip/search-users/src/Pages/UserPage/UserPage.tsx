import { useContext } from "react";
import { useParams } from "react-router-dom";
import Flag from "../../components/Flag/Flag";
import { UserContext } from "../../context/UsersProvider";
import styles from "./UserPage.module.scss"

export default function UserPage() {

  const {search} = useParams(); 
  // Vill ha sök parameter här för att få ut user ur context

  const [initUsers] = useContext(UserContext); 
  // Hämta in users från kontext

  const user = initUsers?.find(user => user.login.uuid === search);

  const dateFormat = () => {
    const date = user && new Date(user.registered.date);
    const year = date && date.getFullYear().toString();
    const month = date && (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date && date.getDate().toString().padStart(2, '0');
    
    return `${year}-${month}-${day}`
  }
  
  return <div className={styles.wrapper}>
    <div className={styles.inner_wrapper}>
      <h1 className={styles.header}>
        {user?.name.first} {user?.name.last}
      </h1>
      <div className={styles.profile}>
        <img src={user?.picture.large} className={styles.profile_picture} alt={user?.name.first} />
        {user && <ul className={styles.info}>
          <li>
            <h2>Nationalitet</h2> 
            <div className={styles.nationality}>
              <Flag code={user.nat} className={styles.flag}/> {user.location.country} ({user.nat})
            </div>
          </li>
          <li>
            <h2>Registrerad</h2>
            {dateFormat()}
          </li>
          <li>
            <h2>Telefon</h2> 
            <a href={`tel:${user.phone}`}>{user.phone}</a>
          </li>
          <li>
            <h2>Epost</h2> 
            <a href={`mailto:${user.email}`}>{user.email}</a>
          </li>
          <li>
            <h2>Kön</h2> 
            {user.gender}
          </li>
          <li>
            <h2>Adress:</h2> 
            {user.location.street.name} {user.location.street.number}<br />
            {user.location.postcode} {user.location.city}
            <div>
              <a href={`http://maps.google.com/?ie=UTF8&hq=&ll=${user.location.coordinates.latitude},${user.location.coordinates.longitude}&z=5`} target='_blank' rel='noreferrer' className={styles.link_button}>
                <i className="fa-solid fa-arrow-up-right-from-square"></i> Se på Google Maps
              </a>
            </div>
          </li>
        </ul>}
      </div>
    </div>
  </div>
}