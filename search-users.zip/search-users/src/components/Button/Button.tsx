import classNames from "classnames"
import styles from "./Button.module.scss"

type props = {
  children: JSX.Element | string,
  className?: string,
  role?: 'button' | 'checkbox',
  selected?: boolean,
  notSelected?: boolean,
  onClick: () => void,
  ariaLabel?: string
}

export default function Button ({children,className, role: _role, selected, onClick, notSelected, ariaLabel} : props) {

  const role = _role ? _role : 'button';

  return _role === 'checkbox' 
  ? <button 
    role={role}
    aria-checked={selected 
      ? 'true' 
      : 'false'
    }
    onClick={onClick} 
    aria-label={ariaLabel}
    className={classNames(styles.filter_button, notSelected && styles.not_selected, className)}
  >
    {children}
  </button>
  : <button 
  aria-label={ariaLabel}
  role={role}
  onClick={onClick} 
  className={classNames(styles.filter_button, notSelected && styles.not_selected, className)}
>
  {children}
</button>
}

