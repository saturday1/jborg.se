import classNames from "classnames";
import { useCallback, useEffect, useMemo, useState } from "react";
import { api } from "../../types";
import { capitalizeStr } from "../../utils/capitalizeString";
import Button from "../Button/Button";
import styles from "./Filters.module.scss"

type props = {
  filters: {[key:string] : string[]},
  searchVal: string,
  initUsers: api.User[] | undefined,
  setUsers: (users: api.User[]) => void,
  filterCount: (count:number) => void; 
}

export default function Filters ({filters, searchVal, initUsers, setUsers, filterCount} : props) {

const filterCategories = useMemo(() => Object.keys(filters), [filters]); // Key strängar till array, kör useMemo då reultatet ej ska ändras i appen
const [selectedFilters, setSelectedFilters] = useState<{[key: string]: string[]}>({}); // För att hålla reda på valda filter


// Filterfunktion, sparar den som callback så att den inte omrenderas
const handleFilterClick = useCallback((cat: string, subCat: string) => {

  setSelectedFilters((prevFilters) => {

    // För att hantera filter lokalt här i callback innan jag sätter det till state skapar jag newFilter
    const newFilters = {...prevFilters};

    if(!newFilters[cat]) {
      // selected filters innehåller inte kategorin
      newFilters[cat] = [subCat] // sätt kategorin med sub kategorin
    } else {
      // selected filters innehåller kategorin
      const subIndex = newFilters[cat].indexOf(subCat); // Ta ut index, om det finns på sub kategori

      if(subIndex === -1) {
        // Sub kategorin finns inte
        newFilters[cat] = [...newFilters[cat], subCat] // Lägg ihop sub kategori med ny sub kategori
      } else {
        // Sub kategorin finns
        const newSubCats = [
          ...newFilters[cat].slice(0, subIndex), // Array innan index
          ...newFilters[cat].slice(subIndex + 1) // Array efter index
        ];

        if (newSubCats.length === 0) {
          // Finns inga sub kategorier i kategori, så ta bort kategorin
          delete newFilters[cat];
        } else {
          // Sub kategorier finns, så skicka in listan med sub kategorier utan denna sub kategori 
          newFilters[cat] = newSubCats;
        }
      }
    }
    // Sätt state till newFilters
    return newFilters
  })
}, [])


useEffect(() => {

  // Tar ut längden på valda filter för att kunna presentera det i knappen
  const filterLength = Object.keys(selectedFilters).flatMap(cat => selectedFilters[cat]).length
  filterCount(filterLength)

  const filtersExists = Object.keys(selectedFilters).length > 0; // Finns filter satta?
  let filteredUsers = initUsers!; // Skapar en let som jag kan ändra nedan, tvingar initUser att vara definierad för TS

  if(filtersExists && initUsers) {
    // Filter är satta och initUser är inte undefined

    for(const cat in selectedFilters) {
      // loopa igenom filtrena
      filteredUsers = filteredUsers.filter(user => {
        // Kolla om selectedFilters[cat] (nat eller gender här) innehåller user[cat]

        // Lyckas inte rätta till detta TS problem som grundar sig i att en user inte alltid har [key: string] : string. Vissa obj values är objekt på user. Dock vet jag här att så är inte fallet här. Så länge grund filtret mappar mot stäng så fungerar det

        // @ts-ignore: Unreachable code error
        return selectedFilters[cat].includes(user[cat]);
      })
    }
  } else {
    filteredUsers = initUsers! // initUsers existerar, annars har det redan kraschat
  }

  if(searchVal.length > 0) {
    // Ifall det är ett sökvärde i searchVal så filtrerar jag träffarna även på det
    filteredUsers = filteredUsers.filter(user => user.fullName.toLowerCase().includes(searchVal.toLowerCase()))
  }
  
  setUsers(filteredUsers);

}, [selectedFilters, searchVal]) // Kör useEffect ifall selectedFilters eller sökvärde ändras


return <div className={styles.filter_wrapper}>
  <h2>Välj kategorier du vill inkludera i resultat</h2>
  <div className={styles.filter_buttons_wrapper}>
    {
    // loopa igenom kategorierna, loopa sedan ut subkategorierna av kategorin
    filterCategories.map(cat => filters[cat].map(subCat => {
      const notSelected = !selectedFilters[cat]?.includes(subCat) &&
      Object.keys(selectedFilters).length > 0 // kollar så att subcat inte finns i selectedFilters samt att selectedFilters inte är nollställt
      const selected = selectedFilters[cat]?.includes(subCat); // Finns subcat i cat, då är den vald

      // Knapparna nedan är egentligen semantiskt sett checkboxar, så de får den rollen. aria-checked fångar upp (för skärmläsare) ifall knappen/checkboxen är checkad eller ej.

      return (
        <Button
          role='checkbox'
          key={subCat}
          onClick={() => handleFilterClick(cat, subCat)}
          className={classNames(styles.filter_button, notSelected && styles.not_selected)}
        >
          <>
            {capitalizeStr(subCat)}
            {selected 
              ? <i className="fa-regular fa-circle-check"></i>
              : <i className="fa-regular fa-circle"></i>
            }
          </>
        </Button>
    )}))}
  </div>
</div>
}