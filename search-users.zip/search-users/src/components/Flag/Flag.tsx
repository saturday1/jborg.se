
type props = {
  code: string,
  className?: string
}

export default function Flag({code, className} : props) {

  return <img src={`https://static.cupmanager.net/images/flags_svg/1x1/${code.toLowerCase()}.svg`} alt={code} className={className} />

}