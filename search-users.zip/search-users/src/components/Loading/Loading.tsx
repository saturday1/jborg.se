import styles from './Loading.module.scss';

export default function PageLoadingNoTranslation () {
  return <div className={styles.loading_layer}></div>
}