import Logo from "../Logo/Logo";
import styles from "./PageHeader.module.scss"

export default function PageHeader () {

  return <div className={styles.wrapper}>
    <Logo fill='white ' />
  </div>
}