import { useContext } from "react";
import { UserContext } from "../../context/UsersProvider";
import PageLoadingNoTranslation from "../Loading/Loading";


// Sätter bara denna komponent för att enkelt kunna hantera laddningen
export default function PagesWrapper ({children} : {children: JSX.Element}) {

  const [initUsers, loading] = useContext(UserContext); 

  return <>{loading 
    ? <PageLoadingNoTranslation/>
    : <>{children}</>
  }</>
}