import ReactDOM from "react-dom";

type props = {
  children: string | JSX.Element,
  id: string,
  nodeRef: React.MutableRefObject<HTMLElement | null>
}

export default function Portal ({children, nodeRef, id} : props) {

  const portal = document.getElementById(id);
  console.log(portal)

  if(!portal) return null

  return ReactDOM.createPortal(
    <>{children}</>,
    portal
  )
}