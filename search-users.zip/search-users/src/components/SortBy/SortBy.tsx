import { useEffect, useState } from "react";
import { api } from "../../types"
import Button from "../Button/Button";
import styles from "./SortBy.module.scss"

type props = {
  users: api.User[] | undefined,
  setUsers: (users:api.User[]) => void
}

export default function SortBy ({users, setUsers} : props) {
  const [sortProps, setSortProps] = useState({
    nameSortKeys: ['first', 'last'],
    asc: true,
    sortedAtKey: 'first' as 'first' | 'last' // Startsorteringsvärde när det mountas
  })

  useEffect(() => {
    // tar fram index på sorterad i array
    const nameSortIndex = sortProps.nameSortKeys.indexOf(sortProps.sortedAtKey);

    // Vilket är nästa index?
    const nextSortKeyIndex = nameSortIndex === sortProps.nameSortKeys.length -1
      ? 0 // Arrayen är slut, ta första index
      : nameSortIndex + 1 // Ta nästa index
      
    const nextSortKey = sortProps.nameSortKeys[nextSortKeyIndex]; // Ta fram värdet på detta index


    
    const sortedUsers = users && [...users].sort((a, b) => {

      // Jag vet att first och last finns under name på user, men TS vet det inte. Lite osäker på hur jag ska hantera det här, så fuskar mig ur det.

      // @ts-ignore: Unreachable code error
      const compareNames = sortProps.asc 
        ? a.name[sortProps.sortedAtKey].localeCompare(b.name[sortProps.sortedAtKey]) // Asc ordning
        : b.name[sortProps.sortedAtKey].localeCompare(a.name[sortProps.sortedAtKey]) // Desc ordning
      
      return compareNames !== 0 // Namnen är lika, sortera på nästa värde i nameSortKeys
        ? compareNames
        : sortProps.asc
          // @ts-ignore: Unreachable code error
          ? a.name[nextSortKey].localeCompare(b.name[nextSortKey]) // Asc ordning
          // @ts-ignore: Unreachable code error
          : b.name[nextSortKey].localeCompare(a.name[nextSortKey]) // Desc ordning
    })

    sortedUsers && setUsers(sortedUsers)
  }, [sortProps]) // Lyssna på ifall sortProps ändras


  return <div>
    <h2>Sortera på</h2>
    <div className={styles.sorting_buttons_wrapper}>
      {sortProps.nameSortKeys.map(sortKey => {

      const description=`${sortProps.asc 
        ? `Sorterar fallande. ${sortKey === sortProps.sortedAtKey 
          ? 'Ändra sorteringsordning.' 
          : 'Sortera på denna.'}` 
        : ` Sorterar stigande. ${sortKey === sortProps.sortedAtKey 
          ? 'Ändra sorteringsordning.' 
          : 'Sortera på denna.'}`}`
      
      return <Button key={sortKey} ariaLabel={description} notSelected={sortKey !== sortProps.sortedAtKey} onClick={() => {
        if(sortKey === sortProps.sortedAtKey) {
          // Vi klickar på aktiv knapp, ändra sorteringsordning
          setSortProps({
            ...sortProps,
            asc: !sortProps.asc 
          })
        } else {
          // Vi klickar på "ny" knapp, ändra sortedAtKey till denna
          setSortProps({
            ...sortProps,
            sortedAtKey: sortKey as 'first' | 'last'
          })
        }
      }}>
        <>
          {sortKey === 'first' ? <>Förnamn</> : <>Efternamn</>}
          {sortKey === sortProps.sortedAtKey && <>
            {sortProps.asc 
              ? <i className="fa-solid fa-arrow-down-a-z"></i> 
              : <i className="fa-solid fa-arrow-down-z-a"></i>
            }
          </>}
        </>
      </Button>}
      )}
    </div>
  </div>
}