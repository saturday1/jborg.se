import { useEffect, useRef, useState } from "react"
import Button from "../Button/Button"
import styles from "./ToggleDropdown.module.scss"
import { CSSTransition } from "react-transition-group"
import classNames from "classnames"
import { keyboardKey } from "@testing-library/user-event"

type props = {
  children: JSX.Element,
  title: string,
  icon?: string
}

/* Använder mig av CSStransition för att kunna göra animationen jag tänkt för dropdown */

export default function ToggleDropdown ({children, title, icon} : props) {
  const transitionTimeout = 300; // Styr samtliga animationers transition i komponenten
  const [open, setOpen] = useState(false);

  const ddRef = useRef(null); // Dropdown element
  const ddOuterRef = useRef<HTMLDivElement | null>(null); // Yttre wrapper som har både knapp och dropdown för min eventlyssnare

  useEffect(() => {
    // Klick utanför dropdown funktion
    const clickHandler = (e: MouseEvent) => {
      if(ddOuterRef.current && !ddOuterRef.current.contains(e.target as Node)) {
        // Jag sätter alltid false här iom att dropdown ska stängas
        setOpen(false);
      }
    }

    const keyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setOpen(false)
      }
    }

    // Lyssna på klick för att avgöra om det är utanför dropdown
    window.addEventListener('mousedown', clickHandler);

    // Lyssna på keydown. Stäng ifall man trycker escape
    window.addEventListener('keydown', keyDown);

    // Ta bort event-lyssnare om komponenten unmountas
    return () => {
      window.removeEventListener('click', clickHandler)
      window.removeEventListener('keydown', keyDown)
    }
  }, [])

  return <div className={styles.dd_wrapper} style={{'--timeout' : `${transitionTimeout}ms`} as any} ref={ddOuterRef}>
    <Button onClick={() => setOpen(!open)}>
      <>
        {icon && <i className={icon}></i>} {title} <i className={classNames(styles.arrow, open && styles.rotate_180, "fa-solid fa-angle-down")}></i>
      </>
    </Button>

    <div>
      <CSSTransition
        in={open}
        timeout={transitionTimeout}
        classNames={{
          enter: styles.ddEnter,
          enterActive: styles.ddEnterActive,
          enterDone: styles.ddEnterDone,
          exit: styles.ddExit,
          exitActive: styles.ddExitActive,
          exitDone: styles.ddExitDone
        }}
        ref={ddRef}
        aria-expanded={open}
      >
        <div ref={ddRef} className={styles.dropdown} aria-hidden={!open}>
          <>
            {children}
          </>
        </div>
      </CSSTransition>
    </div>
  </div>
}