import { api } from "../../types"
import Flag from "../Flag/Flag";
import styles from "./UserCard.module.scss"
import { Link } from "react-router-dom";
import classNames from "classnames";

type props = {
  user: api.User
}

export default function UserCard ({user} : props) {


  return <Link to={`/${user.login.uuid}`} className={classNames(styles.link, 'observer_card')}>
    <article className={styles.wrapper}>
      <div className={styles.profile_picture}>
        <img src={user.picture.medium} alt={user.name.first}/>
      </div>
      <div className={styles.profile_info_wrapper}>
        <header>
          <h3 className={styles.name}>
            <Flag code={user.nat} className={styles.flag} /> <span className={styles.user_name}>{user.fullName}</span>
          </h3>
        </header>
        <p className={styles.info}>
          <i className="fa-solid fa-location-dot"></i> {user.location.city}, {user.location.country}
        </p>
      </div>
    </article>
  </Link>
}