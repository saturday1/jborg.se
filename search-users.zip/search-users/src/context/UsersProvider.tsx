import React from "react";
import { useEffect, useState } from "react";
import { api } from "../types";

// Vill ha data i context så att jag enklare kan nå datan från samtliga komponenter uta att propsa in det
export const UserContext = React.createContext<[api.User[] | undefined, boolean]>([undefined, false]);


export default function UsersProvider({children} : {children: JSX.Element}) {

  const [users, setUsers] = useState<api.User[] | undefined>(undefined);
  const [loading, setLoading] = useState(false) // Bara lite laddningshantering

  useEffect(() => {
    // hämta data och sätt det till state
    setLoading(true);
    fetch('https://randomuser.me/api/?seed=foobar&results=200&nat=us,gb,fi,dk')
      .then(response => response.json())
      .then(data => {
        const users = data.results.map((user:api.User) => ({
          ...user,
          fullName: `${user.name.first} ${user.name.last}`, // Lägger till fullName för att kunna göra exakta sökningar på för och efternamn enklare
        }))
        setUsers(users) 
        setLoading(false) // sluta ladda
      })
      .catch(error => console.error(error)); // Kan vara bättre felhantering, men i mån av tid. Just nu låtsas vi att det aldrig krashar helt enkelt :)
  }, []);

  return <UserContext.Provider value={[users, loading]}>
    {children}
  </UserContext.Provider>
}