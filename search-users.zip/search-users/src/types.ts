// Types
export namespace api {
  export type User = {
    cell: string;
    dob: {
      date: string;
      age: number;
    };
    email: string;
    gender: string;
    id: {
      name: string;
      value: string;
    };
    location: {
      city: string;
      coordinates: {
        latitude: string;
        longitude: string;
      };
      country: string;
      postcode: number;
      state: string;
      street: {
        name: string;
        number: number;
      };
      timezone: {
        description: string;
        offset: string;
      };
    };
    fullName: string,
    name: {
      first: string;
      last: string;
      title: string;
    };
    
    nat: string;
    phone: string;
    picture: {
      large: string;
      medium: string;
      thumbnail: string;
    };
    login: {
      password: string;
      salt: string;
      username: string;
      md5: string;
      sha1: string;
      sha256: string;
      uuid: string;
    }
    registered: {
      age: number;
      date: string;
      dateMs?: number;
    }
  }
}