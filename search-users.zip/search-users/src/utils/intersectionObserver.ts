export const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    entry.target.classList.toggle('show', entry.isIntersecting);
    
    // Sluta observera när elementet kommit in i webbläsaren
    if(entry.isIntersecting) observer.unobserve(entry.target);
  })
}, {
  rootMargin: '0px',
  threshold: .5
});